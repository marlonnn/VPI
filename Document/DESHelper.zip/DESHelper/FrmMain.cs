﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VPITest.Common;

namespace DESHelper
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void textBox7_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                // Assign the file names to a string array, in 
                // case the user has selected multiple files.
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                try
                {
                    this.textBox7.Text = files[0];
                    this.textBox6.Text = Util.GetMD5(this.textBox7.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    return;
                }
            }
        }

        private void textBox7_DragEnter(object sender, DragEventArgs e)
        {
            // If the data is a file or a bitmap, display the copy cursor.
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (this.textBox4.Text.Length > 0 && this.textBox5.Text.Length > 0)
                {
                    this.textBox3.Text = Summer.System.Security.DESHelper.Encrypt(textBox4.Text, textBox5.Text);
                }
            }
            catch (Exception ee)
            {
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            try
            {
                if (this.textBox1.Text.Length > 0)
                {
                    this.textBox2.Text = Summer.System.Security.DESHelper.Encrypt(textBox1.Text, 
                        Summer.System.Data.SmrDbProvider.DESKey);
                }
            }
            catch (Exception ee)
            {
            }
        }
    }
}
